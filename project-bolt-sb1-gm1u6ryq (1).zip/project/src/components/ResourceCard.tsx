import React from 'react';
import { BookOpen, Link as LinkIcon, Tag } from 'lucide-react';

interface ResourceCardProps {
  title: string;
  description: string;
  type: 'article' | 'video' | 'journal';
  tags: string[];
  url: string;
}

export function ResourceCard({ title, description, type, tags, url }: ResourceCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
          <p className="text-gray-600 mb-4 line-clamp-2">{description}</p>
          <div className="flex flex-wrap gap-2 mb-4">
            {tags.map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                <Tag className="w-3 h-3 mr-1" />
                {tag}
              </span>
            ))}
          </div>
        </div>
        <div className="ml-4">
          <BookOpen className="w-6 h-6 text-blue-500" />
        </div>
      </div>
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center text-sm text-blue-600 hover:text-blue-800"
      >
        <LinkIcon className="w-4 h-4 mr-1" />
        View Resource
      </a>
    </div>
  );
}