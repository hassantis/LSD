import React from 'react';
import { GraduationCap, BookOpen, Users, FileText } from 'lucide-react';
import { NavButton } from './NavButton';
import { InstallButton } from '../InstallButton/InstallButton';

export function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <GraduationCap className="h-8 w-8 text-blue-600" />
            <h1 className="ml-2 text-2xl font-bold text-gray-900">LSD Study App</h1>
          </div>
          <div className="flex items-center space-x-4">
            <nav className="flex space-x-4">
              <NavButton icon={BookOpen} label="Resources" />
              <NavButton icon={Users} label="Collaborate" />
              <NavButton icon={FileText} label="Citations" />
            </nav>
            <InstallButton />
          </div>
        </div>
      </div>
    </header>
  );
}