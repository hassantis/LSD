import React from 'react';
import { BrainCog } from 'lucide-react';

interface ThinkingPromptProps {
  question: string;
  category: string;
}

export function ThinkingPrompt({ question, category }: ThinkingPromptProps) {
  return (
    <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 border border-purple-100">
      <div className="flex items-start space-x-4">
        <div className="bg-purple-100 rounded-full p-2">
          <BrainCog className="w-6 h-6 text-purple-600" />
        </div>
        <div>
          <span className="text-sm font-medium text-purple-600 mb-2 block">
            {category}
          </span>
          <p className="text-gray-800 font-medium">{question}</p>
        </div>
      </div>
    </div>
  );
}