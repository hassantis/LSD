import React from 'react';
import { Download } from 'lucide-react';
import { useInstallPrompt } from '../../hooks/useInstallPrompt';

export function InstallButton() {
  const { isInstallable, handleInstallClick } = useInstallPrompt();

  if (!isInstallable) return null;

  return (
    <button
      onClick={handleInstallClick}
      className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
    >
      <Download className="w-4 h-4 mr-2" />
      Install App
    </button>
  );
}