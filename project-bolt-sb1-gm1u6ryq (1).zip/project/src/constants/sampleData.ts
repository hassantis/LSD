export const SAMPLE_RESOURCES = [
  {
    title: "Understanding Research Methods",
    description: "A comprehensive guide to academic research methodologies and best practices.",
    type: "article",
    tags: ["research", "methodology", "academic"],
    url: "https://example.com/research-methods"
  },
  {
    title: "Critical Analysis Techniques",
    description: "Learn how to analyze academic sources and evaluate their credibility.",
    type: "video",
    tags: ["critical thinking", "analysis"],
    url: "https://example.com/critical-analysis"
  }
];

export const THINKING_PROMPTS = [
  {
    question: "How do the different sources complement or contradict each other?",
    category: "Analysis"
  },
  {
    question: "What potential biases might exist in these sources?",
    category: "Evaluation"
  }
];