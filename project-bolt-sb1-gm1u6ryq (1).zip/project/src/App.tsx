import React, { useState } from 'react';
import { GraduationCap, BookOpen, Users, FileText } from 'lucide-react';
import { SearchBar } from './components/SearchBar';
import { ResourceCard } from './components/ResourceCard';
import { ThinkingPrompt } from './components/ThinkingPrompt';

const SAMPLE_RESOURCES = [
  {
    title: "Understanding Research Methods",
    description: "A comprehensive guide to academic research methodologies and best practices.",
    type: "article",
    tags: ["research", "methodology", "academic"],
    url: "https://example.com/research-methods"
  },
  {
    title: "Critical Analysis Techniques",
    description: "Learn how to analyze academic sources and evaluate their credibility.",
    type: "video",
    tags: ["critical thinking", "analysis"],
    url: "https://example.com/critical-analysis"
  }
];

const THINKING_PROMPTS = [
  {
    question: "How do the different sources complement or contradict each other?",
    category: "Analysis"
  },
  {
    question: "What potential biases might exist in these sources?",
    category: "Evaluation"
  }
];

function App() {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // In a real app, this would trigger an API call
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-blue-600" />
              <h1 className="ml-2 text-2xl font-bold text-gray-900">StudyBuddy</h1>
            </div>
            <nav className="flex space-x-4">
              <button className="text-gray-600 hover:text-gray-900 flex items-center">
                <BookOpen className="h-5 w-5 mr-1" />
                Resources
              </button>
              <button className="text-gray-600 hover:text-gray-900 flex items-center">
                <Users className="h-5 w-5 mr-1" />
                Collaborate
              </button>
              <button className="text-gray-600 hover:text-gray-900 flex items-center">
                <FileText className="h-5 w-5 mr-1" />
                Citations
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Section */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Explore Your Research Topic
          </h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Enter a keyword or phrase to discover academic resources, generate critical thinking prompts,
            and develop your understanding.
          </p>
          <SearchBar onSearch={handleSearch} />
        </div>

        {/* Resources Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {SAMPLE_RESOURCES.map((resource, index) => (
            <ResourceCard key={index} {...resource} />
          ))}
        </div>

        {/* Thinking Prompts */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-12">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">
            Critical Thinking Prompts
          </h3>
          <div className="grid gap-4">
            {THINKING_PROMPTS.map((prompt, index) => (
              <ThinkingPrompt key={index} {...prompt} />
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;